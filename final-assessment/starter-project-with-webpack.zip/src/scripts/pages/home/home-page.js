export default class HomePage {
  async render() {
    return `
      <section class="container">
        <h1></h1>
        <div id="loading-message">Memuat cerita...</div>
        <div id="stories-list" class="stories-grid"></div>
      </section>
    `;
  }

  async afterRender() {
    const storiesList = document.querySelector('#stories-list');
    const loadingMessage = document.querySelector('#loading-message');

    if (!storiesList || !loadingMessage) return;

    const token = localStorage.getItem('accessToken');
    if (!token) {
      storiesList.innerHTML = `<p>Anda belum login. Silakan <a href="#/login">login</a> terlebih dahulu.</p>`;
      loadingMessage.style.display = 'none';
      return;
    }

    try {
      const response = await fetch('https://story-api.dicoding.dev/v1/stories', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      const result = await response.json();

      if (!result.error && Array.isArray(result.listStory)) {
        const stories = result.listStory;

        loadingMessage.style.display = 'none';

        storiesList.innerHTML = stories.map((story) => {
          const truncatedDescription = story.description.length > 100
            ? `${story.description.substring(0, 100)}...`
            : story.description;

          return `
            <div class="story-card">
              <img src="${story.photoUrl}" alt="${story.name}" class="story-image" />
              <h3>${story.name}</h3>
              <p>${truncatedDescription}</p>
              <button class="detail-button" onclick="window.location.hash='#/detail/${story.id}'">
                Detail Cerita
              </button>
            </div>
          `;
        }).join('');
      } else {
        if (result.message === 'Invalid token') {
          alert('Sesi Anda telah berakhir. Silakan login kembali.');
          window.location.hash = '/login';
        } else {
          storiesList.innerHTML = `<p>${result.message}</p>`;
        }
      }
    } catch (error) {
      loadingMessage.style.display = 'none';
      storiesList.innerHTML = `<p>Gagal memuat cerita. Coba lagi nanti.</p>`;
    }
  }
}
