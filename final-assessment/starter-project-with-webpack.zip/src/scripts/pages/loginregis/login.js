export default class LoginPage {
  async render() {
    return `
      <section class="container">
        <h1>Login</h1>
        <form id="login-form">
          <label for="login-email">Email</label>
          <input type="email" id="login-email" name="email" required>
  
          <label for="login-password">Password</label>
          <input type="password" id="login-password" name="password" required minlength="8">
  
          <button type="submit">Login</button>
          <p style="margin-top: 1rem; text-align:center;">
        Belum punya akun? <a href="#/regis" id="register-link">Daftar di sini</a>
      </p>
        </form>
      </section>
    `;
  }

  async afterRender() {
    const form = document.querySelector('#login-form');

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const email = document.querySelector('#login-email').value.trim();
      const password = document.querySelector('#login-password').value.trim();

      try {
        const response = await fetch('https://story-api.dicoding.dev/v1/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });

        const result = await response.json();

        if (!response.ok) {
          throw new Error(result.message || 'Login gagal! Periksa kredensial Anda.');
        }

        alert('Login berhasil!');
        localStorage.setItem('accessToken', result.loginResult.token);
        localStorage.setItem('name', result.loginResult.name);
        
        window.location.hash = '#/';
      } catch (error) {
        alert(error.message || 'Terjadi kesalahan saat login. Coba lagi.');
      }
    });
  }
}
