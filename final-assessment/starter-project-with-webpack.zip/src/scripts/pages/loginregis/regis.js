export default class RegisterPage {
    async render() {
      return `
        <section class="container">
          <h1>Daftar</h1><br>
          <form id="register-form">
            <label for="register-name">Nama</label>
            <input type="text" id="register-name" name="name" required>
  
            <label for="register-email">Email</label>
            <input type="email" id="register-email" name="email" required>
  
            <label for="register-password">Password</label>
            <input type="password" id="register-password" name="password" required minlength="8">
  
            <button type="submit">Daftar</button>
             <p style="margin-top: 1rem; text-align: center;">
        Sudah punya akun? <a href="#/login">Login di sini</a>
      </p>
          </form>
        </section>
      `;
    }
  
    async afterRender() {
      const form = document.querySelector('#register-form');
      form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const name = document.querySelector('#register-name').value;
        const email = document.querySelector('#register-email').value;
        const password = document.querySelector('#register-password').value;
  
        try {
          const response = await fetch('https://story-api.dicoding.dev/v1/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password }),
          });
  
          const result = await response.json();
          if (!result.error) {
            alert('Registrasi berhasil! Silakan login.');
            window.location.hash = '#/login';
          } else {
            alert(result.message);
          }
        } catch (error) {
          alert('Registrasi gagal! Coba lagi.');
        }
      });
    }
  }
  