export default class DetailStoryPage {
  constructor(storyId) {
    this.storyId = storyId;
  }

  async render() {
    return `
      <section class="container">
        <h1>Detail Cerita</h1>
        <div id="loading-message">Memuat detail cerita...</div>
        <div id="story-detail"></div>
      </section>
    `;
  }

  async afterRender() {
    const storyDetail = document.querySelector('#story-detail');
    const loadingMessage = document.querySelector('#loading-message');

    const token = localStorage.getItem('accessToken');
    if (!token) {

      storyDetail.innerHTML = `<p>Anda belum login. Silakan <a href="#/login">login</a> terlebih dahulu.</p>`;
      loadingMessage.style.display = 'none';
      return;
    }

    try {
      const response = await fetch(`https://story-api.dicoding.dev/v1/stories/${this.storyId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      const result = await response.json();

      if (!result.error) {
        const { name, description, photoUrl, createdAt, lat, lon } = result.story;

        loadingMessage.style.display = 'none';

        storyDetail.innerHTML = `
          <div class="story-card">
            <img src="${photoUrl}" alt="${name}" class="story-image" />
            <h3>${name}</h3>
            <p>${description}</p>
            <p><strong>Dibuat pada:</strong> ${new Date(createdAt).toLocaleString()}</p>
            ${lat && lon ? `<p><strong>Lokasi:</strong> ${lat}, ${lon}</p>` : ''}
          </div>
          <button id="back-to-home" class="back-button">Kembali ke Home</button>
        </div>
        `;
        document.querySelector('#back-to-home').addEventListener('click', () => {
          window.location.hash = '#/';
        });

      } else {
        storyDetail.innerHTML = `<p>${result.message}</p>`;
      }
    } catch (error) {
      loadingMessage.style.display = 'none';
      storyDetail.innerHTML = `<p>Gagal memuat detail cerita. Coba lagi nanti.</p>`;
    }
  }
}
