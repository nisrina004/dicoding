export default class AddStoryPage {
  async render() {
    return `
      <section class="container">
        <h1>Tambah Cerita Baru</h1><br>
        <form id="add-story-form" enctype="multipart/form-data">
          <label for="story-description">Deskripsi</label>
          <textarea id="story-description" name="description" required></textarea>

          <label for="story-image">Pilih Gambar dari Galeri</label>
          <input 
            type="file" 
            id="story-image" 
            name="photo"
            accept="image/*"
          />

          <p>Ambil Gambar dari Kamera</p>
          <video id="camera-video" autoplay playsinline style="width: 100%; max-height: 300px; border: 1px solid #ccc; margin-top: 1rem;"></video>
          <canvas id="camera-canvas" style="display: none;"></canvas>
          <button type="button" id="camera-take-button" style="margin-top: 0.5rem;">Ambil Gambar</button>

          <img id="preview-image" alt="Pratinjau Gambar" style="display: none; max-width: 100%; margin-top: 1rem;" />

          <p>Pilih Lokasi</p>
          <div id="map-container" style="height: 300px; margin-bottom: 1rem;"></div>

          <input type="hidden" id="latitude" name="lat" required />
          <input type="hidden" id="longitude" name="lon" required />

          <button type="submit" style="margin-top: 1rem;">Kirim Cerita</button>
        </form>
      </section>
    `;
  }

  async afterRender() {
    const map = L.map('map-container').setView([-6.200000, 106.816666], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    let marker;
    map.on('click', (e) => {
      const { lat, lng } = e.latlng;
      if (marker) marker.setLatLng(e.latlng);
      else marker = L.marker([lat, lng]).addTo(map);

      document.querySelector('#latitude').value = lat;
      document.querySelector('#longitude').value = lng;
    });

    const imageInput = document.querySelector('#story-image');
    const previewImage = document.querySelector('#preview-image');
    let galleryImageFile = null;

    imageInput.addEventListener('change', (event) => {
      const file = event.target.files[0];
      if (file && file.size <= 1048576) { 
        galleryImageFile = file;

        const reader = new FileReader();
        reader.onload = (e) => {
          previewImage.src = e.target.result;
          previewImage.style.display = 'block';
        };
        reader.readAsDataURL(file);
      } else {
        alert('Ukuran gambar harus kurang dari 1MB.');
        previewImage.style.display = 'none';
      }
    });

    const cameraVideo = document.getElementById('camera-video');
    const cameraCanvas = document.getElementById('camera-canvas');
    const cameraTakeButton = document.getElementById('camera-take-button');

    let cameraImageFile = null;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      cameraVideo.srcObject = stream;

      cameraVideo.addEventListener('loadedmetadata', () => {
        cameraCanvas.width = cameraVideo.videoWidth || 640;
        cameraCanvas.height = cameraVideo.videoHeight || 480;
      });

      cameraTakeButton.addEventListener('click', async () => {
        const context = cameraCanvas.getContext('2d');
        context.drawImage(cameraVideo, 0, 0, cameraCanvas.width, cameraCanvas.height);

        const blob = await new Promise((resolve) =>
          cameraCanvas.toBlob(resolve, 'image/jpeg', 1.0)
        );

        if (blob && blob.size <= 1048576) {
          cameraImageFile = new File([blob], 'camera_image.jpg', { type: 'image/jpeg' });

          previewImage.src = URL.createObjectURL(cameraImageFile);
          previewImage.style.display = 'block';
        } else {
          alert('Gagal mengambil gambar dari kamera atau ukuran melebihi 1MB.');
        }
      });

    } catch (error) {
      console.error('Gagal mengakses kamera:', error);
      alert('Kamera tidak dapat diakses. Pastikan izin telah diberikan dan perangkat mendukung fitur kamera.');
    }

    const form = document.querySelector('#add-story-form');

    form.addEventListener('submit', async (event) => {
      event.preventDefault();

      const formData = new FormData(form);
      
      const description = document.querySelector('#story-description').value.trim();
      formData.set('description', description);

      if (cameraImageFile) {
        formData.set('photo', cameraImageFile, cameraImageFile.name);
      } else if (galleryImageFile) {
        formData.set('photo', galleryImageFile, galleryImageFile.name);
      } else {
        alert('Harap pilih atau ambil gambar terlebih dahulu.');
        return;
      }

      try {
        const token = localStorage.getItem('accessToken');
        if (!token) {
          alert('Anda belum login.');
          window.location.hash = '#/login';
          return;
        }
        
        const response = await fetch('https://story-api.dicoding.dev/v1/stories', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          body: formData,
        });
        

        const result = await response.json();

        if (!result.error) {
          alert('Cerita berhasil dikirim!');
          window.location.hash = '#/';
        } else {
          alert(`Gagal mengirim cerita: ${result.message}`);
        }
      } catch (error) {
        console.error('Gagal mengirim data:', error);
        alert('Gagal mengirim cerita. Silakan coba lagi.');
      }
    });
    window.addEventListener('hashchange', () => {
      if (cameraVideo.srcObject) {
        const tracks = cameraVideo.srcObject.getTracks();
        tracks.forEach((track) => track.stop());
        cameraVideo.srcObject = null;
      }
    });
    
  }
}
