import routes from '../routes/routes';

class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this._setupDrawer();
  }

  _setupDrawer() {
    this.#drawerButton.addEventListener('click', () => {
      this.#navigationDrawer.classList.toggle('open');
    });

    document.body.addEventListener('click', (event) => {
      if (!this.#navigationDrawer.contains(event.target) && !this.#drawerButton.contains(event.target)) {
        this.#navigationDrawer.classList.remove('open');
      }

      this.#navigationDrawer.querySelectorAll('a').forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove('open');
        }
      })
    });
  }

  async renderPage() {
    const url = window.location.hash.slice(1).toLowerCase() || '/';
    const page = routes[url];

    const mainElement = document.querySelector('#main-content');

    if (!page) {
        mainElement.innerHTML = '<h2>Halaman tidak ditemukan!</h2>';
        return;
    }

    mainElement.innerHTML = await page.render();
    await page.afterRender?.(); 
}


}

export default App;
