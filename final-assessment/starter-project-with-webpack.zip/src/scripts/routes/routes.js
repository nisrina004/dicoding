import AboutPage from '../pages/about/about-page';
import HomePage from '../pages/home/home-page';
import LoginPage from '../pages/loginregis/login';
import RegisterPage from '../pages/loginregis/regis';
import AddStoryPage from '../pages/story/addstorypage';
import StoryDetailPage from '../pages/story/detailstorypage';
import LocationPage from '../peta/lokasi';

const routes = {
  '/': new HomePage(),
  '/about': new AboutPage(),
  '/regis': new RegisterPage(),
  '/login': new LoginPage(),
  '/add-story' : new AddStoryPage(),
  '/detail/:id': new StoryDetailPage(),
  '/lokasi': new LocationPage(),
};

export default routes;
