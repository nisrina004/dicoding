export function tampilkanPetaLokasiPengguna(containerId) {
  const map = L.map(containerId).setView([0, 0], 13); // inisialisasi awal

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
  }).addTo(map);

  if (!navigator.geolocation) {
    alert('Geolocation tidak didukung di browser ini.');
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (position) => {
      const currentCoords = [
        position.coords.latitude,
        position.coords.longitude,
      ];

      const name = localStorage.getItem('name') || 'Kamu';

      map.setView(currentCoords, 15);

      L.marker(currentCoords)
        .addTo(map)
        .bindPopup(`lokasi ${name} sekarang.`)
        .openPopup();
    },
    () => {
      alert('Gagal mendapatkan lokasi kamu.');
    }
  );
}
