import { tampilkanPetaLokasiPengguna } from './peta.js';

export default class LocationPage {
  async render() {
    return `
      <section class="container">
        <h1>Lokasi Saya Sekarang</h1>
        <div id="current-location-map" style="height: 400px; margin-top: 1rem;"></div>
      </section>
    `;
  }

  async afterRender() {
    tampilkanPetaLokasiPengguna('current-location-map');
  }
}
