const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  APP_URL: 'https://myapp.com', 
  MAP_SERVICE_API_KEY: 'your-map-api-key-here',
};

export default CONFIG;
