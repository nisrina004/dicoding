import CONFIG from '../config';

const ENDPOINTS = {
  REGISTER: `${CONFIG.BASE_URL}/register`,
  LOGIN: `${CONFIG.BASE_URL}/login`,
  ADD_STORY: `${CONFIG.BASE_URL}/stories`,
  ADD_STORY_GUEST: `${CONFIG.BASE_URL}/stories/guest`,
};

export async function registerUser({ name, email, password }) {
  try {
    const response = await fetch(ENDPOINTS.REGISTER, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });

    if (!response.ok) {
      throw new Error('Failed to register');
    }

    return await response.json();
  } catch (error) {
    alert(error.message);
  }
}

export async function loginUser({ email, password }) {
  const response = await fetch(ENDPOINTS.LOGIN, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });

  const result = await response.json();
  if (!result.error) {
    localStorage.setItem('token', result.loginResult.token);
  }
  return result;
}

export async function addStory({ description, photo, lat, lon, isGuest = false }) {
  if (photo.size > 1048576) {
    alert('Ukuran gambar terlalu besar (maksimal 1MB).');
    return;
  }

  const formData = new FormData();
  formData.append('description', description);
  formData.append('photo', photo);
  if (lat) formData.append('lat', lat);
  if (lon) formData.append('lon', lon);

  const endpoint = isGuest ? ENDPOINTS.ADD_STORY_GUEST : ENDPOINTS.ADD_STORY;

  const headers = isGuest
    ? {}
    : { Authorization: `Bearer ${localStorage.getItem('token')}` };

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers,
      body: formData,
    });

    const result = await response.json();
    if (!result.error) {
      alert('Story berhasil ditambahkan!');
    } else {
      throw new Error(result.message || 'Gagal menambahkan story');
    }
  } catch (error) {
    alert(error.message);
  }
}
