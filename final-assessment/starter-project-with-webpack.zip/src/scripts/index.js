import '../styles/styles.css';

import App from './pages/app';
import AddStoryPage from './pages/story/addstorypage';
import DetailStoryPage from './pages/story/detailstorypage';

async function handleRouting() {
  const hash = window.location.hash;

  // Cek halaman berdasarkan hash
  if (hash.startsWith('#/detail/')) {
    const storyId = hash.split('/')[2];
    const detailStoryPage = new DetailStoryPage(storyId);
    document.querySelector('#main-content').innerHTML = await detailStoryPage.render();
    await detailStoryPage.afterRender();
  } else if (hash === '#/add-story') {
    const addStoryPage = new AddStoryPage();
    document.querySelector('#main-content').innerHTML = await addStoryPage.render();
    await addStoryPage.afterRender();
  } else {
    // Halaman default (gunakan app)
    const app = new App({
      content: document.querySelector('#main-content'),
      drawerButton: document.querySelector('#drawer-button'),
      navigationDrawer: document.querySelector('#navigation-drawer'),
    });
    await app.renderPage();
  }

  // Pasang ulang tombol logout setelah DOM berubah
  const logoutButton = document.querySelector('#logout-button');
  if (logoutButton) {
    logoutButton.addEventListener('click', (event) => {
      event.preventDefault();
      const confirmed = confirm('Yakin ingin logout?');
      if (confirmed) {
        localStorage.removeItem('accessToken');
        alert('Berhasil logout!');
        window.location.hash = '#/login';
      }
    });
  }

  // Pasang ulang tombol daftar kalau ada
  const daftarButton = document.querySelector('#daftar-button');
  if (daftarButton) {
    daftarButton.addEventListener('click', () => {
      window.location.hash = '#/login';
    });
  }
}

// Event awal ketika DOM siap
window.addEventListener('DOMContentLoaded', handleRouting);

// Event saat navigasi berubah
window.addEventListener('hashchange', handleRouting);
