import StoryApi from '../../data/story-api';

export default class HomePresenter {
  constructor(view) {
    this.view = view;
  }

  async loadStories() {
    this.view.showLoading();

    const result = await StoryApi.getStories();

    this.view.hideLoading();

    if (result.error) {
      if (result.message === 'Token tidak ditemukan. Silakan login.') {
        this.view.showLoginPrompt();
      } else {
        this.view.showError(result.message);
      }
    } else {
      this.view.showStories(result.listStory);
    }
  }
}
