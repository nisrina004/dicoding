import HomePresenter from './homepresenter';

export default class HomePage {
  constructor() {
    this.presenter = new HomePresenter(this);
  }

  async render() {
    return `
      <section class="container">
        <h1>Daftar Cerita</h1>
        <div id="loading-message">Memuat cerita...</div>
        <div id="stories-list" class="stories-grid"></div>
      </section>
    `;
  }

  async afterRender() {
    this.presenter.loadStories();
  }
 showLoading() {
    document.querySelector('#loading-message').style.display = 'block';
  }

  hideLoading() {
    document.querySelector('#loading-message').style.display = 'none';
  }

  showLoginPrompt() {
    const storiesList = document.querySelector('#stories-list');
    storiesList.innerHTML = `<p>Anda belum login. Silakan <a href="#/login">login</a> terlebih dahulu.</p>`;
  }

  showError(message) {
    const storiesList = document.querySelector('#stories-list');
    storiesList.innerHTML = `<p>${message}</p>`;
  }

  showStories(stories) {
    const storiesList = document.querySelector('#stories-list');
    storiesList.innerHTML = stories.map((story) => {
      const cleanedDescription = story.description.replace('||ME', '').trim();
      const truncatedDescription = cleanedDescription.length > 100
        ? `${cleanedDescription.substring(0, 100)}...`
        : cleanedDescription;
        const createdAt = new Date(story.createdAt);
        const formattedDate = createdAt.toLocaleString('id-ID', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        });
    
        return `
          <div class="story-card">
            <img src="${story.photoUrl}" alt="${story.name}" class="story-image" />
            <h3>${story.name}</h3>
            <p>${truncatedDescription}</p>
            <p class="story-date">${formattedDate}</p>
            <a class="detail-button" href="#/detail/${story.id}">
            Detail Cerita</a>
          </div>
        `;
      }).join('');
    }
}
