export default class PetaPage {
  constructor() {
    this._map = null;
  }

  async render() {
    return `
      <section class="container">
        <h1 id="story-title">Peta Cerita</h1>
        <p id="story-description">Menampilkan lokasi cerita dari seluruh pengguna.</p>
        <div id="peta-lokasi" style="height: 400px; margin-top: 1rem;"></div>
        <a href="#/" class="back-home-button">← Kembali ke Beranda</a>
      </section>
    `;
  }

  async afterRender() {
    const accessToken = localStorage.getItem('accessToken');

    if (!accessToken) {
      document.getElementById('peta-lokasi').innerHTML = '<p>Harap login terlebih dahulu.</p>';
      return;
    }

    try {
      const response = await fetch('https://story-api.dicoding.dev/v1/stories?location=1', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!data || !data.listStory || data.listStory.length === 0) {
        document.getElementById('peta-lokasi').innerHTML = '<p>Tidak ada data lokasi yang tersedia.</p>';
        return;
      }

      const storiesWithLocation = data.listStory.filter(story => story.lat && story.lon);

      if (storiesWithLocation.length === 0) {
        document.getElementById('peta-lokasi').innerHTML = '<p>Tidak ada cerita dengan lokasi tersedia.</p>';
        return;
      }

      const firstLat = storiesWithLocation[0].lat;
      const firstLon = storiesWithLocation[0].lon;

      const map = L.map('peta-lokasi').setView([firstLat, firstLon], 13);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(map);

      
      storiesWithLocation.forEach((story) => {
        const { name, description, lat, lon, createdAt } = story;
        const formattedDate = new Date(createdAt).toLocaleString('id-ID', {
          dateStyle: 'medium',
          timeStyle: 'short',
        });

        L.marker([lat, lon])
          .addTo(map)
          .bindPopup(`
            <strong>${name || 'Tanpa Judul'}</strong><br>
            ${description || ''}<br>
            <small><em>${formattedDate}</em></small><br>
           <small>📍 Lat: ${lat.toFixed(5)}, Lon: ${lon.toFixed(5)}</small>
    `);
});

      document.getElementById('story-title').textContent = 'Peta Cerita Pengguna';
      document.getElementById('story-description').textContent = `Total cerita ditemukan: ${storiesWithLocation.length}`;
    } catch (err) {
      console.error(err);
      document.getElementById('peta-lokasi').innerHTML = '<p>Gagal memuat data lokasi.</p>';
    }
  }
}
