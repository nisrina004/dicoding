import StoryApi from '../../data/story-api';
import DetailStoryPresenter from './detailstorypresenter';

export default class DetailStoryPage {
  constructor(storyId) {
    this.storyId = storyId;
  }

  async render() {
    return `
      <section class="container">
        <h1>Detail Cerita</h1>
        <div id="loading-message">Memuat detail cerita...</div>
        <div id="story-detail"></div>
      </section>
    `;
  }

  async afterRender() {
    this._storyDetailContainer = document.querySelector('#story-detail');
    this._loadingMessage = document.querySelector('#loading-message');

    const presenter = new DetailStoryPresenter({
      view: this,
      storyApi: StoryApi,
      storyId: this.storyId,
    });

    presenter.init();
  }
  _waitUntilLeafletLoaded() {
    return new Promise((resolve) => {
      const check = () => {
        if (window.L) {
          resolve();
        } else {
          setTimeout(check, 100);
        }
      };
      check();
    });
  }
  
  showLoading() {
    this._loadingMessage.style.display = 'block';
    this._storyDetailContainer.innerHTML = '';
  }

  showNotLoggedIn() {
    this._loadingMessage.style.display = 'none';
    this._storyDetailContainer.innerHTML = `
      <p>Anda belum login. Silakan <a href="#/login">login</a> terlebih dahulu.</p>
    `;
  }

  showError(message) {
    this._loadingMessage.style.display = 'none';
    this._storyDetailContainer.innerHTML = `<p>${message}</p>`;
  }

  showStoryDetail(story) {
    this._loadingMessage.style.display = 'none';
  
    const createdAtFormatted = new Date(story.createdAt).toLocaleString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  
    const mapContainer = story.lat && story.lon
      ? `<div id="map-container-detail" style="height: 300px; margin-top: 1rem;"></div>`
      : `<p>📍 Lokasi tidak tersedia</p>`;
  
    this._storyDetailContainer.innerHTML = `
      <div class="story-card">
        <img src="${story.photoUrl}" alt="${story.name}" class="story-detail-image" />
        <h2>${story.name}</h2>
        <p class="story-date">${createdAtFormatted}</p>
        <p>${story.description}</p>
        ${mapContainer}
        <a href="#/" class="back-button">← Kembali</a>
      </div>
    `;
  
    setTimeout(() => {
      const mapContainer = document.getElementById('map-container-detail');
      console.log('🗺️ Map container ditemukan?', !!mapContainer);
    
      if (!mapContainer) {
        console.error('Map container tidak ditemukan!');
        return;
      }
    
      const map = L.map(mapContainer).setView([story.lat, story.lon], 15);
    
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(map);
    
      L.marker([story.lat, story.lon]).addTo(map)
      .bindPopup(`<strong>📍 Koordinat:</strong><br>Lat: ${story.lat}<br>Lon: ${story.lon}`)
        .openPopup();
    }, 200);
  }    
  
}
