import StoryApi from '../../data/story-api';
import AddStoryPresenter from './addstorypresenter';

export default class AddStoryPage {
  async render() {
    return `
      <section class="container" style="max-width: 600px; margin: 0 auto; padding: 2rem;">
        <h1 style="text-align: center; margin-bottom: 2rem;">📝 Tambah Cerita Baru</h1>

        <form id="add-story-form" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 1rem;">
          
          <label for="story-description"><strong>Deskripsi Cerita</strong></label>
          <textarea 
            id="story-description" 
            name="description" 
            required 
            rows="4"
            placeholder="Tulis pengalaman atau cerita kamu di sini..."
            style="padding: 0.75rem; border-radius: 8px; border: 1px solid #ccc;"
          ></textarea>

          <label for="story-image"><strong>📁 Pilih Gambar dari Galeri</strong></label>
          <input 
            type="file" 
            id="story-image" 
            name="photo"
            accept="image/*"
            style="padding: 0.5rem;"
          />

          <div style="margin-top: 1rem;">
            <p><strong>📷 Ambil Gambar dari Kamera</strong></p>
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
              <button id="open-camera-button" type="button" style="flex: 1; padding: 0.5rem; background-color: #D16B86; color: white; border: none; border-radius: 6px;">Buka Kamera</button>
              <button id="camera-take-button" type="button" style="flex: 1; padding: 0.5rem; background-color: #D16B86; color: white; border: none; border-radius: 6px;" disabled>Ambil Gambar</button>
              <button id="close-camera-button" type="button" style="flex: 1; padding: 0.5rem; background-color: #D16B86; color: white; border: none; border-radius: 6px;">Tutup Kamera</button>
            </div>

            <video 
              id="camera-video" 
              autoplay 
              playsinline 
              style="display: none; width: 100%; margin-top: 1rem; border-radius: 8px; border: 1px solid #ccc;"
            ></video>
            <canvas id="camera-canvas" style="display: none;"></canvas>
          </div>

          <img 
            id="preview-image" 
            alt="Pratinjau Gambar" 
            style="display: none; max-width: 100%; border-radius: 8px; border: 1px solid #ccc;"
          />

          <p><strong>📍 Pilih Lokasi pada Peta</strong></p>
          <div 
            id="map-container" 
            style="height: 300px; border-radius: 8px; border: 1px solid #ccc; overflow: hidden;"
          ></div>

          <input type="hidden" id="latitude" name="lat" required />
          <input type="hidden" id="longitude" name="lon" required />

          <button 
            type="submit id="submit-button" 
            style="margin-top: 1rem; padding: 0.75rem; background-color:#D16B86; color: white; border: none; border-radius: 8px; font-weight: bold;"
          >
            🚀 Kirim Cerita
          </button>
        </form>
      </section>
    `;
  }

  async afterRender() {
    const presenter = new AddStoryPresenter({
      view: this,
      storyApi: StoryApi,
    });
    presenter.init();
  }

  showLoading() {
    const button = document.querySelector('button[type="submit"]');
    if (button) {
      button.disabled = true;
      button.innerHTML = '⏳ Mengirim...';
    }
  }

  hideLoading() {
    const button = document.querySelector('button[type="submit"]');
    if (button) {
      button.disabled = false;
      button.innerHTML = '🚀 Kirim Cerita';
    }
  }

  showSuccess(message) {
    alert(`✅ ${message}`);
  }

  showError(message) {
    alert(`❌ ${message}`);
  }



}
