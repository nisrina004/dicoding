export default class DetailStoryPresenter {
  constructor({ view, storyApi, storyId }) {
    this.view = view;
    this.storyApi = storyApi;
    this.storyId = storyId;
  }

  async init() {
    this.view.showLoading();

    const token = localStorage.getItem('accessToken');
    if (!token) {
      this.view.showNotLoggedIn();
      return;
    }

    try {
      const result = await this.storyApi.getStoryById(this.storyId);
      if (!result.error) {
        const cleanedStory = {
          ...result.story,
          name: result.story.name === 'me' ? 'Anonim' : result.story.name,
          description: result.story.description?.replace('||ME', '').trim() || ''
        };
        this.view.showStoryDetail(cleanedStory);
      } else {
        this.view.showError(result.message);
      }
    } catch (error) {
      this.view.showError('Terjadi kesalahan saat memuat detail cerita.');
      console.error(error);
    }
  }
  
}
