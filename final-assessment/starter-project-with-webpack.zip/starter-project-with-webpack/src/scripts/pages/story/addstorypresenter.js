export default class AddStoryPresenter {
  constructor({ view, storyApi }) {
    this.view = view;
    this.storyApi = storyApi;
    this.capturedPhoto = null;
  }

  async init() {
    const token = localStorage.getItem('accessToken');
    if (!token) {
      this.view.showError('Anda harus login terlebih dahulu.');
      return;
    }

    this.view.showLoading();

    this._initMap();
    this._setupCamera();
    this._setupFormListener(token);
  }

  _setupCamera() {
    const openBtn = document.getElementById('open-camera-button');
    const takeBtn = document.getElementById('camera-take-button');
    const closeBtn = document.getElementById('close-camera-button');
    const video = document.getElementById('camera-video');
    const canvas = document.getElementById('camera-canvas');
    const preview = document.getElementById('preview-image');

    let stream;

    openBtn.addEventListener('click', async () => {
      stream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = stream;
      video.style.display = 'block';
      takeBtn.disabled = false;
    });

    takeBtn.addEventListener('click', () => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0);
      canvas.toBlob((blob) => {
        this.capturedPhoto = blob;

        const previewUrl = URL.createObjectURL(blob);
        preview.src = previewUrl;
        preview.style.display = 'block';
      }, 'image/jpeg');
    });

    closeBtn.addEventListener('click', () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      video.style.display = 'none';
      takeBtn.disabled = true;
    });
  }

  _setupFormListener(token) {
    const form = document.querySelector('#add-story-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      this.view.showLoading();
  
      const description = document.querySelector('#story-description').value;
      const fileImage = document.querySelector('#story-image').files[0];
      const lat = document.querySelector('#latitude').value;
      const lon = document.querySelector('#longitude').value;
  
      if (!lat || !lon) {
        this.view.showError('Silakan pilih lokasi pada peta terlebih dahulu.');
        this.view.hideLoading();
        return;
      }
  
      let photo = null;
      if (this.capturedPhoto) {
        photo = new File([this.capturedPhoto], 'captured.jpg', { type: 'image/jpeg' });
      } else if (fileImage) {
        photo = fileImage;
      } else {
        this.view.showError('Silakan pilih atau ambil gambar terlebih dahulu.');
        this.view.hideLoading();
        return;
      }
  
      try {
        const result = await this.storyApi.addStory({
          description,
          photo,
          lat,
          lon,
        });
  
        this.view.hideLoading();
  
        if (!result.error) {
          this.view.showSuccess('Cerita berhasil dikirim!');
          setTimeout(() => {
            window.location.hash = '#/lokasi';
          }, 1000);
        } else {
          this.view.showError(result.message);
        }
      } catch (err) {
        this.view.hideLoading();
        this.view.showError('Gagal mengirim cerita. Silakan coba lagi.');
        console.error(err);
      }
    });
  }  

  _initMap() {
    const mapContainer = document.getElementById('map-container');
    if (!mapContainer) return;

    const defaultLat = -6.200000;
    const defaultLon = 106.816666;

    const map = L.map('map-container').setView([defaultLat, defaultLon], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);

    let marker;

    map.on('click', function (e) {
      const { lat, lng } = e.latlng;

      document.querySelector('#latitude').value = lat;
      document.querySelector('#longitude').value = lng;

      if (marker) {
        marker.setLatLng([lat, lng]);
      } else {
        marker = L.marker([lat, lng]).addTo(map);
      }
    });
  }
}
