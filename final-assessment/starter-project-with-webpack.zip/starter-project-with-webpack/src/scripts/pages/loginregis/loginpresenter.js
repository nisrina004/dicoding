const LoginPresenter = {
    async handleLogin(event) {
      event.preventDefault();
  
      const email = document.querySelector('#login-email').value.trim();
      const password = document.querySelector('#login-password').value.trim();
  
      try {
        const response = await fetch('https://story-api.dicoding.dev/v1/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        });
  
        const result = await response.json();
  
        if (!response.ok) {
          throw new Error(result.message || 'Login gagal! Periksa kredensial Anda.');
        }
  
        alert('Login berhasil!');
        localStorage.setItem('accessToken', result.loginResult.token);
        localStorage.setItem('name', result.loginResult.name);
  
        window.location.hash = '#/';
      } catch (error) {
        alert(error.message || 'Terjadi kesalahan saat login. Coba lagi.');
      }
    }
  };
  
  export default LoginPresenter;
  