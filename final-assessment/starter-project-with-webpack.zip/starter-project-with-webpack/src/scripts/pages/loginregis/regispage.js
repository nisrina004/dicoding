import RegisterPresenter from './registerpresenter';

export default class RegisterPage {
  async render() {
    return `
      <section class="container">
        <h1>Daftar</h1><br>
        <form id="register-form">
          <label for="register-name">Nama</label>
          <input type="text" id="register-name" name="name" required autocomplete="name">

          <label for="register-email">Email</label>
          <input type="email" id="register-email" name="email" required autocomplete="email">

          <label for="register-password">Password</label>
          <input type="password" id="register-password" name="password" required minlength="8">

          <button type="submit">Daftar</button>
          <p style="margin-top: 1rem; text-align: center;">
            Sudah punya akun? <a href="#/login">Login di sini</a>
          </p>
        </form>
      </section>
    `;
  }

  async afterRender() {
    const presenter = new RegisterPresenter(this);
    presenter.init();
  }
}
