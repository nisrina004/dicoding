export default class RegisterPresenter {
    constructor(view) {
      this.view = view;
      this.form = null;
    }
  
    init() {
      this.form = document.querySelector('#register-form');
      this.form?.addEventListener('submit', this.handleRegister.bind(this));
    }
  
    async handleRegister(event) {
      event.preventDefault();
    
      const name = this.form.querySelector('#register-name').value.trim();
      const email = this.form.querySelector('#register-email').value.trim();
      const password = this.form.querySelector('#register-password').value;
    
      if (!name || !email || !password) {
        alert('Semua field wajib diisi!');
        return;
      }
    
      if (password.length < 8) {
        alert('Password minimal 8 karakter.');
        return;
      }
    
      console.log({ name, email, password });
    
      try {
        const response = await fetch('https://story-api.dicoding.dev/v1/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, password }),
        });
    
        const result = await response.json();
    
        if (!result.error) {
          alert('Registrasi berhasil! Silakan login.');
          window.location.hash = '#/login';
        } else {
          alert(result.message);
        }
      } catch (error) {
        alert('Registrasi gagal! Coba lagi.');
        console.error(error);
      }
    }
    
  }
  