import LoginPresenter from './loginpresenter.js';

export default class LoginPage {
  async render() {
    return `
      <section class="container">
        <h1>Login</h1>
        <form id="login-form">
          <label for="login-email">Email</label>
          <input type="email" id="login-email" name="email" required autocomplete="email">

          <label for="login-password">Password</label>
          <input type="password" id="login-password" name="password" required minlength="8">

          <button type="submit">Login</button>
          <p style="margin-top: 1rem; text-align:center;">
            Belum punya akun? <a href="#/regis" id="register-link">Daftar di sini</a>
          </p>
        </form>
      </section>
    `;
  }

  async afterRender() {
    const form = document.querySelector('#login-form');
    form.addEventListener('submit', (event) => LoginPresenter.handleLogin(event));
  }
}
