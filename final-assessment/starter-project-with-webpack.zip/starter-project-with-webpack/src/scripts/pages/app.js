import routes from '../routes/routes';
import { getActiveRoute } from '../routes/url-parser';

export default class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this._setupDrawer();
  }

  _setupDrawer() {
    this.#drawerButton?.addEventListener('click', () => {
      this.#navigationDrawer?.classList.toggle('open');
    });

    document.body.addEventListener('click', (event) => {
      if (
        !this.#navigationDrawer?.contains(event.target) &&
        !this.#drawerButton?.contains(event.target)
      ) {
        this.#navigationDrawer?.classList.remove('open');
      }

      this.#navigationDrawer?.querySelectorAll('a')?.forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove('open');
        }
      });
    });
  }

  async renderPage() {
    const mainElement = this.#content;
    const routeName = getActiveRoute();
    let page = routes[routeName];

    // Tangani dynamic route seperti /detail/:id
    if (!page) {
      const urlSegments = routeName.split('/');
      if (urlSegments[1] === 'detail') {
        const id = urlSegments[2];
        page = routes['/detail/:id'];
        if (page) {
          page = new page();
          page.storyId = id;
        }
      }
    } else {
      page = typeof page === 'function' ? new page() : page;
    }

    if (!page) {
      mainElement.innerHTML = '<h2>Halaman tidak ditemukan!</h2>';
      mainElement.setAttribute('tabindex', '-1');
      mainElement.focus();
      return;
    }

    const renderContent = async () => {
      mainElement.innerHTML = await page.render();
      mainElement.setAttribute('tabindex', '-1');
      mainElement.focus();
      await page.afterRender?.();
    };

    if (document.startViewTransition) {
      document.startViewTransition(renderContent);
    } else {
      await renderContent();
    }
  }
}
