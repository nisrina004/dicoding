import CONFIG from '../config';

const ENDPOINTS = {
  GET_STORIES: `${CONFIG.BASE_URL}/stories`,
  ADD_STORY: `${CONFIG.BASE_URL}/stories`,
  ADD_STORY_GUEST: `${CONFIG.BASE_URL}/stories/guest`,
};

async function getStories() {
  const token = localStorage.getItem('accessToken');

  if (!token) {
    return {
      error: true,
      message: 'Token tidak ditemukan. Silakan <a href="#/login">login terlebih dahulu</a>.',
    };
  }

  try {
    const response = await fetch(ENDPOINTS.GET_STORIES, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const result = await response.json();

    if (!response.ok || result.error) {
      return {
        error: true,
        message: result.message || 'Gagal memuat cerita.',
      };
    }

    return result;
  } catch (error) {
    return {
      error: true,
      message: error.message || 'Terjadi kesalahan saat memuat cerita.',
    };
  }
}

async function addStory({ description, photo, lat, lon, isGuest = false }) {
  if (!description || !photo) {
    return { error: true, message: 'Deskripsi dan foto wajib diisi.' };
  }

  if (photo.size > 1048576) {
    return { error: true, message: 'Ukuran gambar terlalu besar (maksimal 1MB).' };
  }

  const formData = new FormData();
  formData.append('description', description);
  formData.append('photo', photo);
  if (lat !== undefined && lat !== null) formData.append('lat', lat);
  if (lon !== undefined && lon !== null) formData.append('lon', lon);

  const endpoint = isGuest ? ENDPOINTS.ADD_STORY_GUEST : ENDPOINTS.ADD_STORY;
  const headers = isGuest ? {} : { Authorization: `Bearer ${localStorage.getItem('accessToken')}` };

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers,
      body: formData,
    });

    const result = await response.json();

    if (!response.ok || result.error) {
      return {
        error: true,
        message: result.message || 'Gagal menambahkan cerita.',
      };
    }

    return result;
  } catch (error) {
    return {
      error: true,
      message: error.message || 'Terjadi kesalahan saat menambahkan cerita.',
    };
  }
}

async function getStoryById(id) {
  const token = localStorage.getItem('accessToken');

  if (!token) {
    return {
      error: true,
      message: 'Token tidak ditemukan. Silakan login terlebih dahulu.',
    };
  }

  try {
    const response = await fetch(`${CONFIG.BASE_URL}/stories/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const result = await response.json();

    if (!response.ok || result.error) {
      return {
        error: true,
        message: result.message || 'Gagal memuat detail cerita.',
      };
    }

    return result;
  } catch (error) {
    return {
      error: true,
      message: 'Terjadi kesalahan saat mengambil detail cerita.',
    };
  }
}

export default {
  getStories,
  addStory,
  getStoryById,
};
