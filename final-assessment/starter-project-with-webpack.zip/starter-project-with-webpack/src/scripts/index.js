import '../styles/styles.css';
import App from './pages/app';
import AddStoryPage from './pages/story/addstorypage';
import DetailStoryPage from './pages/story/detailstorypage';
import { registerServiceWorker } from './utils';

const app = new App({
  content: document.querySelector('#main-content'),
  drawerButton: document.querySelector('#drawer-button'),
  navigationDrawer: document.querySelector('#navigation-drawer'),
});

async function handleRouting() {
  const hash = window.location.hash;

  if (hash.startsWith('#/detail/')) {
    const storyId = hash.split('/')[2];
if (!storyId) {
      alert('Story ID tidak ditemukan.');
      window.location.hash = '#/';
      return;
    }
    const detailStoryPage = new DetailStoryPage(storyId);
    document.querySelector('#main-content').innerHTML = await detailStoryPage.render();
    await detailStoryPage.afterRender();
  } else if (hash === '#/add-story') {
    const addStoryPage = new AddStoryPage();
    document.querySelector('#main-content').innerHTML = await addStoryPage.render();
    await addStoryPage.afterRender();
  } else {
      const app = new App({
      content: document.querySelector('#main-content'),
      drawerButton: document.querySelector('#drawer-button'),
      navigationDrawer: document.querySelector('#navigation-drawer'),
    });
    await app.renderPage();
  }

  const logoutButton = document.querySelector('#logout-button');
  if (logoutButton) {
    logoutButton.addEventListener('click', (event) => {
      event.preventDefault();
      const confirmed = confirm('Yakin ingin logout?');
      if (confirmed) {
        localStorage.removeItem('accessToken');
        alert('Berhasil logout!');
        window.location.hash = '#/login';
      }
    });
  }

  const daftarButton = document.querySelector('#daftar-button');
  if (daftarButton) {
    daftarButton.addEventListener('click', () => {
      window.location.hash = '#/login';
    });
  }
}

async function handleNotificationToggle() {
  const notificationIcon = document.querySelector('#notification-icon');

  if (!('Notification' in window)) {
    alert('Browser Anda tidak mendukung notifikasi.');
    return;
  }

  if (Notification.permission === 'default') {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      alert('Notifikasi tidak diizinkan.');
      notificationIcon.textContent = '🔕'; 
      return;
    }
  }

  if (Notification.permission === 'granted') {
    if (notificationIcon.textContent === '🔔') {
      notificationIcon.textContent = '🔕'; 
      alert('Notifikasi dinonaktifkan.');
    } else {
      notificationIcon.textContent = '🔔'; 
      alert('Notifikasi diaktifkan.');
    }
  } else {
    notificationIcon.textContent = '🔕'; // Bell with a slash
    alert('Notifikasi tidak diizinkan.');
  }
}

document.querySelector('#toggle-notifications').addEventListener('click', (event) => {
  event.preventDefault();
  handleNotificationToggle();
});

await registerServiceWorker();

window.addEventListener('DOMContentLoaded', handleRouting);

window.addEventListener('hashchange', async () => {
  await app.renderPage();
});

