import HomePage from '../pages/home/homepage';
import LoginPage from '../pages/loginregis/loginpage';
import RegisterPage from '../pages/loginregis/regispage';
import PetaPage from '../pages/peta/peta';
import AddStoryPage from '../pages/story/addstorypage';
import StoryDetailPage from '../pages/story/detailstorypage';

const routes = {
  '/': new HomePage(),
  '/regis': new RegisterPage(),
  '/login': new LoginPage(),
  '/add-story' : new AddStoryPage(),
  '/detail/:id': new StoryDetailPage(),
  '/lokasi': new PetaPage(),
};

export default routes;
