const BASE_URL = "https://notes-api.dicoding.dev/v2";

export const getNotes = async () => {
    try {
        const response = await fetch(`${BASE_URL}/notes`);
        if (!response.ok) {
            throw new Error('Gagal mengambil data catatan');
        }
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error saat mengambil data:', error);
        return [];
    }
};

export const addNote = async (title, body) => {
    try {
        const response = await fetch(`${BASE_URL}/notes`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, body })
        });

        if (!response.ok) {
            throw new Error('Gagal menambah catatan');
        }

        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error saat menambah catatan:', error);
        return null;
    }
};

export const deleteNote = async (id) => {
    try {
        const response = await fetch(`${BASE_URL}/notes/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error('Gagal menghapus catatan');
        }

        return true; // Sukses hapus catatan
    } catch (error) {
        console.error('Error saat menghapus catatan:', error);
        return false;
    }
};

export const archiveNote = async (id) => {
    try {
        const response = await fetch(`${BASE_URL}/notes/${id}/archive`, {
            method: 'POST'
        });

        if (!response.ok) {
            throw new Error('Gagal mengarsipkan catatan');
        }

        return true; // Sukses arsipkan catatan
    } catch (error) {
        console.error('Error saat mengarsipkan catatan:', error);
        return false;
    }
};

export const unarchiveNote = async (id) => {
    try {
        const response = await fetch(`${BASE_URL}/notes/${id}/unarchive`, {
            method: 'POST'
        });

        if (!response.ok) {
            throw new Error('Gagal membatalkan arsip catatan');
        }

        return true; // Sukses membatalkan arsip
    } catch (error) {
        console.error('Error saat membatalkan arsip catatan:', error);
        return false;
    }
};

export const editNote = async (id, title, body) => {
    try {
        const response = await fetch(`${BASE_URL}/notes/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, body })
        });

        if (!response.ok) {
            throw new Error('Gagal mengedit catatan');
        }

        const result = await response.json();
        return result.data;
    } catch (error) {
        console.error('Error saat mengedit catatan:', error);
        return null;
    }
};
