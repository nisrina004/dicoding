import { addNote, archiveNote, deleteNote, editNote, getNotes, unarchiveNote } from './api';
import './components/app-bar.js';
import './components/note-form.js';
import './components/note-item.js';
import './style.css';

const loadingIndicator = document.getElementById('loading-indicator');

function showLoading() {
    loadingIndicator.classList.remove('hidden');
}

function hideLoading() {
    loadingIndicator.classList.add('hidden');
}

function renderNotes(notes) {
    const activeNotesContainer = document.getElementById('active-notes-container');
    const archivedNotesContainer = document.getElementById('archived-notes-container');

    activeNotesContainer.innerHTML = '';
    archivedNotesContainer.innerHTML = '';

    notes.forEach(note => {
        const noteElement = document.createElement('note-item');
        noteElement.setAttribute('title', note.title);
        noteElement.setAttribute('body', note.body);
        noteElement.setAttribute('createdat', note.createdAt);
        noteElement.setAttribute('id', note.id);
        noteElement.setAttribute('archived', note.archived.toString());

        if (note.archived) {
            archivedNotesContainer.appendChild(noteElement);
        } else {
            activeNotesContainer.appendChild(noteElement);
        }
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    showLoading();
    try {
        const notes = await getNotes();
        console.log('Data diterima:', notes);
        renderNotes(notes);
    } catch (error) {
        console.error('Gagal mengambil data catatan:', error);
        alert('Gagal memuat data catatan. Silakan coba lagi.');
    } finally {
        hideLoading();
    }
});

// Event CRUD
const events = ["delete", "archive", "unarchive", "edit"];

events.forEach(eventName => {
    document.addEventListener(eventName, async (event) => {
        const { id, title, body } = event.detail;

        showLoading();
        try {
            if (eventName === "delete") await deleteNote(id);
            if (eventName === "archive") await archiveNote(id);
            if (eventName === "unarchive") await unarchiveNote(id);
            if (eventName === "edit") {
                const newTitle = prompt("Masukkan judul baru:", title);
                const newBody = prompt("Masukkan isi catatan baru:", body);

                if (newTitle && newBody) {
                    await editNote(id, newTitle, newBody);
                }
            }

            const notes = await getNotes();
            renderNotes(notes);
        } catch (error) {
            console.error(`Gagal memproses ${eventName}:`, error);
            alert(`Gagal memproses ${eventName}. Silakan coba lagi.`);
        } finally {
            hideLoading();
        }
    });
});

document.querySelector('note-form').addEventListener('note-added', async (event) => {
    const { title, body } = event.detail;

    showLoading();
    try {
        const response = await addNote(title, body);
        if (response) {
            alert('Catatan berhasil ditambahkan!');
            const notes = await getNotes();
            renderNotes(notes);
        }
    } catch (error) {
        console.error('Gagal menambah catatan:', error);
        alert('Gagal menambah catatan. Silakan coba lagi.');
    } finally {
        hideLoading();
    }
});

if (module.hot) {
    module.hot.accept();
}
