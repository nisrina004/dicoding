class AppBar extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.shadowRoot.innerHTML = `
      <div style="
  width: 100vw;  
  color: #e57373; 
  padding: 15px 0; 
  text-align: center;
  box-sizing: border-box;
">
  <h1>Notes App</h1>
</div>

    `;
  }
}

if (!customElements.get("app-bar")) {
  customElements.define("app-bar", AppBar);
}
