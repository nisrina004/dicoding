class NoteForm extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.shadowRoot.innerHTML = `
      <style>
        /* Styling untuk kotak form */
        :host {
          display: block;
          width: 100%;
          max-width: 400px;
          margin: 0 auto;
          padding: 20px;
          background-color: #f7b7b3;
          border-radius: 8px;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Styling untuk form */
        #note-form {
          display: grid;
          gap: 15px;
        }

        #note-form input, #note-form textarea, #note-form button {
          padding: 5px;
          border: 1px solid #ccc;
          border-radius: 4px;
          font-size: 1rem;
          width: 100%;
        }

        #note-form textarea {
          height: 100px;
        }

        #note-form button {
          background-color: rgb(185, 57, 47);
          color: white;
          border: none;
          cursor: pointer;
          font-size: 1.1rem;
        }

        #note-form button:hover {
          background-color: #5a3e36;
        }

        .button-container {
          display: flex;
          justify-content: center;
        }
      </style>

      <form id="note-form">
        <label for="title">Judul Catatan</label>
        <input type="text" id="title" name="title" placeholder="Masukkan judul catatan" required />
        <label for="body">Isi Catatan</label>
        <textarea id="body" name="body" placeholder="Masukkan isi catatan" required></textarea>

        <div class="button-container">
          <button type="submit">Tambah Catatan</button>
        </div>
      </form>
    `;

    this.shadowRoot.querySelector("#note-form").addEventListener("submit", this.addNote.bind(this));
  }

  addNote(event) {
    event.preventDefault();
    const title = this.shadowRoot.querySelector("#title").value.trim();
    const body = this.shadowRoot.querySelector("#body").value.trim();

    if (!title || !body) {
      alert("Judul dan isi catatan tidak boleh kosong!");
      return;
    }

    // Membuat objek catatan baru
    const newNote = {
      id: Date.now().toString(),
      title,
      body,
      createdAt: new Date().toISOString(),
      archived: false,
    };

    // Dispatch event untuk menambahkan catatan ke daftar aktif
    this.dispatchEvent(new CustomEvent("note-added", {
      detail: newNote,
      bubbles: true,
      composed: true
    }));

    // Reset form setelah menambah catatan
    this.shadowRoot.querySelector("#title").value = "";
    this.shadowRoot.querySelector("#body").value = "";
  }
}

if (!customElements.get("note-form")) {
  customElements.define("note-form", NoteForm);
}
