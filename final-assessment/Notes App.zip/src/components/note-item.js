class NoteItem extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    const title = this.getAttribute('title');
    const body = this.getAttribute('body');
    const createdAt = new Date(this.getAttribute('createdat'));
    const archived = this.getAttribute('archived') === 'true';
    const id = this.getAttribute('id');

    console.log(`ID Catatan: ${id}`); // Log tambahan untuk cek ID

    const formattedDate = createdAt.toLocaleDateString('id-ID', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    this.shadowRoot.innerHTML = `
      <div class="note-item">
        <h3>${title}</h3>
        <p>${body}</p>
        <p><strong>Created on:</strong> ${formattedDate}</p>
        <div>
          ${archived 
            ? '<button id="unarchive-button">🔓 Unarchive</button>' 
            : '<button id="archive-button">📥 Archive</button>'}
          <button id="edit-button">✏️ Edit</button>
          <button id="delete-button">🗑️ Delete</button>
        </div>
      </div>
    `;

    this.shadowRoot.querySelector("#archive-button")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("archive", {
        detail: { id },
        bubbles: true,
        composed: true
      }));
    });

    this.shadowRoot.querySelector("#unarchive-button")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("unarchive", {
        detail: { id },
        bubbles: true,
        composed: true
      }));
    });

    this.shadowRoot.querySelector("#edit-button")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("edit", {
        detail: { id, title, body },
        bubbles: true,
        composed: true
      }));
    });

    this.shadowRoot.querySelector("#delete-button")?.addEventListener("click", () => {
      this.dispatchEvent(new CustomEvent("delete", {
        detail: { id },
        bubbles: true,
        composed: true
      }));
    });
  }
}

if (!customElements.get("note-item")) {
  customElements.define("note-item", NoteItem);
}
