import HomeView from './homeview.js';

class HomePresenter {
  constructor(container) {
    this.container = container;
    this.view = new HomeView();
  }

  init() {
    const viewElement = this.view.render();
    this.container.appendChild(viewElement);

    const button = viewElement.querySelector('#findMovieBtn');
    button.addEventListener('click', () => {
      alert('Film akan ditampilkan (fitur dalam pengembangan)');
    });
  }
}

export default HomePresenter;
