class HomeView {
  constructor() {
    this.root = document.createElement('div');
    this.root.className = 'home-page';
  }

  render() {
    this.root.innerHTML = `
      <header class="navbar">
        <div class="logo">M FLIX STUDIO</div>
        <nav>
          <a href="#">Home</a>
          <a href="#">About Us</a>
          <a href="#">Comment</a>
        </nav>
      </header>
      <section class="hero">
        <h1 class="logo-text">Mood <span>FLIX STUDIO</span></h1>
        <p>Setiap mood punya cerita, dan setiap cerita punya filmnya sendiri. Temuin semuanya di Moodflix!</p>
        <button id="findMovieBtn">Temukan Film</button>
      </section>
    `;
    return this.root;
  }
}

export default HomeView;
