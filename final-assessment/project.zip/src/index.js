import HomePresenter from './pages/home/homepresenter.js';
import './styles/main.css';

document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById('app');
  const homePresenter = new HomePresenter(root);
  homePresenter.init();
});
